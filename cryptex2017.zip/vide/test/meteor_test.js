Tinytest.add('Instantiation', function(test) {
  test.notEqual(jQuery().vide, undefined);
});
