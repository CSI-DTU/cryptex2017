<?php
define("DBHOST",     "localhost");
define("DBUSER",     "root");
define("DBPASSWORD",    "abcd1234");
define("DBNAME",     "cryptex18");
define("REDIRECTLINK", "http://139.59.87.249");
define("LOGINLINK",REDIRECTLINK."/vide/examples/fb.php");
define("APPLINK","https://www.facebook.com/cryptex2017/app/202980683107053/");
define("DTUSITE", "http://csidtu.tech/");
define("COGENESISSITE", "http://cogenesis.dtu.ac.in/");
?>
