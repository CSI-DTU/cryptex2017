# Cryptex2017
Cryptex 2017

## Technologies Used:
Backend: PHP
DB: MYSQL
Frontend: HTML5/CSS

## Note : 
 Change Database information in core.php and app id in fbapi.php. 
 And Add given SQL Database on your respective Server.
