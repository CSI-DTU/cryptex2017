<?php

    $app_id = "565461693784792";
    $app_secret = "c89075376defb090dd796342027a614f";
   $my_url = "https://apps.facebook.com/quiztest__harsh
";

	// $app_id = "535607983283690";
 //   $app_secret = "79e834c3396b7031a107ebbcdf3b09e3";
 //   $my_url = "https://apps.facebook.com/cryptextest/";

	//$app_id = "964170843665207";
   //$app_secret = "b945176c6ef42c4ed32dc8213401f1ec";
   //$my_url = "https://apps.facebook.com/cryptexlogintest";

   session_start();

 ?>
